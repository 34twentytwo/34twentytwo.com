<?php
/**
 * The template for displaying the footer in PWA.
 *
 * @package Neve
 * @since   2.4.3
 */

?>

<?php wp_footer(); ?>

</body>

</html>
